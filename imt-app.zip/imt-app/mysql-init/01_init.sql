CREATE DATABASE IF NOT EXISTS imt_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE imt_db;

CREATE TABLE IF NOT EXISTS imt_data (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  nomor_hp    VARCHAR(20) NOT NULL UNIQUE,
  nama        VARCHAR(100) NOT NULL,
  tinggi_badan DECIMAL(5,2) NOT NULL COMMENT 'dalam cm',
  berat_badan  DECIMAL(5,2) NOT NULL COMMENT 'dalam kg',
  imt          DECIMAL(6,2) NOT NULL,
  status       VARCHAR(20) NOT NULL,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample data
INSERT IGNORE INTO imt_data (nomor_hp, nama, tinggi_badan, berat_badan, imt, status) VALUES
  ('08978940888', 'Kurniawan', 172.00, 64.00, 21.64, 'Normal'),
  ('084099987555', 'Andi Pratama', 165.00, 80.00, 29.38, 'Obesitas'),
  ('08977140777', 'Siti Rahayu', 158.00, 45.00, 18.04, 'Kurus');
