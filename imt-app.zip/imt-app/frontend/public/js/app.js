// ============================================
// IMT Check App — Frontend Logic
// ============================================

const API_BASE = '/api/imt';

// State
let currentHP = null;
let fromScreen = 'screen-form';

// ===== UTILITY =====
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const target = document.getElementById(id);
  if (target) {
    target.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}

function showLoading(show) {
  document.getElementById('loading-overlay').classList.toggle('hidden', !show);
}

function showError(id, msg) {
  const el = document.getElementById(id);
  el.textContent = msg;
  el.classList.remove('hidden');
}

function clearError(id) {
  const el = document.getElementById(id);
  el.textContent = '';
  el.classList.add('hidden');
}

function statusBadgeClass(status) {
  const map = {
    'Sangat Kurus': 'sangat-kurus',
    'Kurus': 'kurus',
    'Normal': 'normal',
    'Gemuk': 'gemuk',
    'Obesitas': 'obesitas',
  };
  return map[status] || 'normal';
}

async function apiFetch(url, options = {}) {
  const resp = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const json = await resp.json();
  return { ok: resp.ok, status: resp.status, data: json };
}

// ===== MODAL =====
function openModal() {
  document.getElementById('modal-backdrop').classList.remove('hidden');
}
function closeModal() {
  document.getElementById('modal-backdrop').classList.add('hidden');
}

// ===== SCREEN 1: HITUNG =====
async function handleHitung() {
  clearError('form-error');

  const nomor_hp = document.getElementById('inp-hp').value.trim();
  const nama = document.getElementById('inp-nama').value.trim();
  const tinggi_badan = document.getElementById('inp-tinggi').value.trim();
  const berat_badan = document.getElementById('inp-berat').value.trim();

  if (!nomor_hp || !nama || !tinggi_badan || !berat_badan) {
    showError('form-error', 'Semua field wajib diisi.');
    return;
  }
  if (!/^[0-9+]+$/.test(nomor_hp)) {
    showError('form-error', 'Format nomor HP tidak valid.');
    return;
  }
  if (parseFloat(tinggi_badan) <= 0 || parseFloat(berat_badan) <= 0) {
    showError('form-error', 'Tinggi dan berat badan harus lebih dari 0.');
    return;
  }

  showLoading(true);
  try {
    // Check if HP already exists
    const checkRes = await apiFetch(`${API_BASE}/check-hp`, {
      method: 'POST',
      body: JSON.stringify({ nomor_hp }),
    });

    if (!checkRes.ok) throw new Error('Gagal memeriksa nomor HP.');

    if (checkRes.data.exists) {
      // HP already registered → show modal
      currentHP = nomor_hp;
      showLoading(false);
      openModal();
    } else {
      // New data → create and show result
      const createRes = await apiFetch(API_BASE, {
        method: 'POST',
        body: JSON.stringify({ nomor_hp, nama, tinggi_badan, berat_badan }),
      });

      showLoading(false);

      if (!createRes.ok) {
        showError('form-error', createRes.data.message || 'Gagal menyimpan data.');
        return;
      }

      showResultScreen(createRes.data.data);
    }
  } catch (err) {
    showLoading(false);
    showError('form-error', 'Terjadi kesalahan. Periksa koneksi Anda.');
    console.error(err);
  }
}

// ===== MODAL: Lihat existing =====
async function handleLihatExisting() {
  closeModal();
  if (!currentHP) return;

  fromScreen = 'screen-form';
  await loadAndShowDetail(currentHP);
}

// ===== SCREEN 2: LIST =====
async function loadList() {
  const tbody = document.getElementById('list-tbody');
  const loadingEl = document.getElementById('list-loading');
  const emptyEl = document.getElementById('list-empty');
  const tableWrap = document.getElementById('list-table-wrap');

  tbody.innerHTML = '';
  loadingEl.classList.remove('hidden');
  emptyEl.classList.add('hidden');
  tableWrap.classList.add('hidden');

  try {
    const res = await apiFetch(API_BASE);
    loadingEl.classList.add('hidden');

    if (!res.ok) throw new Error('Failed to load');

    const rows = res.data.data;
    if (!rows || rows.length === 0) {
      emptyEl.classList.remove('hidden');
      return;
    }

    rows.forEach(row => {
      const tr = document.createElement('tr');
      const badgeClass = statusBadgeClass(row.status);
      tr.innerHTML = `
        <td class="td-hp">${escHtml(row.nomor_hp)}</td>
        <td>${escHtml(row.nama)}</td>
        <td><span class="badge ${badgeClass}">${escHtml(row.status)}</span></td>
        <td><button class="btn btn-primary btn-sm" onclick="listViewDetail('${escHtml(row.nomor_hp)}')">Lihat</button></td>
      `;
      tbody.appendChild(tr);
    });

    tableWrap.classList.remove('hidden');
  } catch (err) {
    loadingEl.classList.add('hidden');
    emptyEl.textContent = 'Gagal memuat data.';
    emptyEl.classList.remove('hidden');
    console.error(err);
  }
}

async function listViewDetail(nomor_hp) {
  fromScreen = 'screen-list';
  await loadAndShowDetail(nomor_hp);
}

// ===== SCREEN 3: DETAIL =====
async function loadAndShowDetail(nomor_hp) {
  showLoading(true);
  try {
    const res = await apiFetch(`${API_BASE}/${encodeURIComponent(nomor_hp)}`);
    showLoading(false);

    if (!res.ok) {
      alert('Data tidak ditemukan.');
      return;
    }

    const d = res.data.data;
    currentHP = d.nomor_hp;

    document.getElementById('detail-title').textContent = `Data IMT ${d.nomor_hp}`;
    document.getElementById('d-hp').textContent = d.nomor_hp;
    document.getElementById('d-nama').textContent = d.nama;
    document.getElementById('d-tinggi').textContent = `${d.tinggi_badan} cm`;
    document.getElementById('d-berat').textContent = `${d.berat_badan} kg`;

    const statusEl = document.getElementById('d-status');
    const bc = statusBadgeClass(d.status);
    statusEl.innerHTML = `<span class="badge ${bc}">${escHtml(d.status)}</span>`;

    showScreen('screen-detail');
  } catch (err) {
    showLoading(false);
    console.error(err);
    alert('Terjadi kesalahan saat memuat data.');
  }
}

function goBackFromDetail() {
  showScreen(fromScreen);
  if (fromScreen === 'screen-list') loadList();
}

// ===== SCREEN 4: EDIT =====
async function showEditForm() {
  if (!currentHP) return;

  showLoading(true);
  try {
    const res = await apiFetch(`${API_BASE}/${encodeURIComponent(currentHP)}`);
    showLoading(false);

    if (!res.ok) { alert('Gagal memuat data.'); return; }

    const d = res.data.data;
    document.getElementById('edit-title').textContent = `Edit Perhitungan IMT ${d.nomor_hp}`;
    document.getElementById('edit-hp').value = d.nomor_hp;
    document.getElementById('edit-nama').value = d.nama;
    document.getElementById('edit-tinggi').value = d.tinggi_badan;
    document.getElementById('edit-berat').value = d.berat_badan;
    clearError('edit-error');
    showScreen('screen-edit');
  } catch (err) {
    showLoading(false);
    console.error(err);
  }
}

async function handleUpdate() {
  clearError('edit-error');

  const nama = document.getElementById('edit-nama').value.trim();
  const tinggi_badan = document.getElementById('edit-tinggi').value.trim();
  const berat_badan = document.getElementById('edit-berat').value.trim();

  if (!nama || !tinggi_badan || !berat_badan) {
    showError('edit-error', 'Semua field wajib diisi.');
    return;
  }

  showLoading(true);
  try {
    const res = await apiFetch(`${API_BASE}/${encodeURIComponent(currentHP)}`, {
      method: 'PUT',
      body: JSON.stringify({ nama, tinggi_badan, berat_badan }),
    });

    showLoading(false);

    if (!res.ok) {
      showError('edit-error', res.data.message || 'Gagal menyimpan perubahan.');
      return;
    }

    showResultScreen(res.data.data);
  } catch (err) {
    showLoading(false);
    showError('edit-error', 'Terjadi kesalahan. Periksa koneksi Anda.');
    console.error(err);
  }
}

// ===== SCREEN 5: RESULT =====
function showResultScreen(data) {
  document.getElementById('result-title').textContent = `Hasil Perhitungan IMT ${data.nomor_hp}`;
  document.getElementById('result-score-val').textContent = parseFloat(data.imt).toFixed(2);

  const badgeClass = statusBadgeClass(data.status);
  const badgeEl = document.getElementById('result-badge');
  badgeEl.textContent = data.status;
  badgeEl.className = `badge lg ${badgeClass}`;

  document.getElementById('r-hp').textContent = data.nomor_hp;
  document.getElementById('r-nama').textContent = data.nama;
  document.getElementById('r-tinggi').textContent = `${data.tinggi_badan} cm`;
  document.getElementById('r-berat').textContent = `${data.berat_badan} kg`;

  showScreen('screen-result');
}

// ===== HELPERS =====
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ===== INIT =====
// Override showScreen to load list when navigating to it
const _origShowScreen = showScreen;
window.showScreen = function(id) {
  _origShowScreen(id);
  if (id === 'screen-list') loadList();
};

// Enter key support on form inputs
['inp-hp','inp-nama','inp-tinggi','inp-berat'].forEach(id => {
  const el = document.getElementById(id);
  if (el) el.addEventListener('keydown', e => { if (e.key === 'Enter') handleHitung(); });
});
