# 🏥 Aplikasi IMT (Indeks Massa Tubuh)

Aplikasi fullstack untuk menghitung dan menyimpan data IMT (BMI).

## Stack
- **Backend**: Node.js + Express.js
- **Database**: PostgreSQL
- **Frontend**: Vanilla HTML/CSS/JS (disajikan via Nginx)
- **Container**: Docker + Docker Compose
- **CI/CD**: GitLab CI/CD

---

## 🚀 Cara Menjalankan (Development Lokal)

### 1. Clone & Setup
```bash
git clone <repo-url>
cd imt-app
cp .env.example .env
# Edit .env sesuai kebutuhan
```

### 2. Jalankan dengan Docker Compose
```bash
docker compose up -d --build
```

### 3. Akses Aplikasi
- **Frontend**: http://localhost
- **API Health**: http://localhost/health
- **API Docs**: http://localhost/api/imt

---

## 📡 API Endpoints

| Method | Endpoint                    | Deskripsi                  |
|--------|-----------------------------|----------------------------|
| GET    | /api/imt                   | Ambil semua data           |
| GET    | /api/imt/check/:nomor_hp   | Cek apakah HP terdaftar    |
| GET    | /api/imt/:nomor_hp         | Ambil data by nomor HP     |
| POST   | /api/imt                   | Tambah data baru           |
| PUT    | /api/imt/:nomor_hp         | Update data                |
| DELETE | /api/imt/:nomor_hp         | Hapus data                 |

---

## 🔄 Setup GitLab CI/CD

### 1. Tambahkan CI/CD Variables di GitLab
GitLab → Project → Settings → CI/CD → Variables:

| Variable         | Type   | Nilai                          |
|------------------|--------|-------------------------------|
| `VPS_HOST`       | Var    | IP address VPS kamu           |
| `VPS_USER`       | Var    | User SSH (misal: ubuntu)      |
| `VPS_SSH_KEY`    | File   | Private key SSH               |
| `VPS_PORT`       | Var    | 22                            |
| `APP_DIR`        | Var    | /opt/imt-app                  |
| `DB_PASSWORD`    | Var    | Password DB yang kuat         |

### 2. Setup VPS
```bash
# Di VPS:
sudo apt update && sudo apt install -y docker.io docker-compose-plugin
sudo usermod -aG docker $USER
mkdir -p /opt/imt-app/nginx
```

### 3. Push ke GitLab
Pipeline akan otomatis:
1. **Build** image Docker
2. **Push** ke GitLab Container Registry
3. **Deploy** ke VPS via SSH

---

## 📋 Klasifikasi IMT
| Nilai IMT       | Status        |
|-----------------|---------------|
| < 17            | Sangat Kurus  |
| 17 – < 18.5     | Kurus         |
| 18.5 – 25       | Normal        |
| 25 – 27         | Gemuk         |
| > 27            | Obesitas      |

**Rumus**: `IMT = Berat (kg) ÷ [Tinggi (m) × Tinggi (m)]`
