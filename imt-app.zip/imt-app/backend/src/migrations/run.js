const pool = require('../config/database');

const migrate = async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS imt_data (
        id SERIAL PRIMARY KEY,
        nomor_hp VARCHAR(20) UNIQUE NOT NULL,
        nama VARCHAR(100) NOT NULL,
        tinggi_badan DECIMAL(5,2) NOT NULL,
        berat_badan DECIMAL(5,2) NOT NULL,
        imt_score DECIMAL(6,2),
        status VARCHAR(20),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `);
    console.log('✅ Migration completed: imt_data table ready');
    process.exit(0);
  } catch (err) {
    console.error('❌ Migration failed:', err);
    process.exit(1);
  }
};

migrate();
