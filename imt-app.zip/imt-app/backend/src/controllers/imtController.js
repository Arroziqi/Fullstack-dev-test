const pool = require('../config/database');

const calculateIMT = (berat, tinggi) => {
  const tinggiM = tinggi / 100;
  return berat / (tinggiM * tinggiM);
};

const getStatus = (imt) => {
  if (imt < 17) return 'Sangat Kurus';
  if (imt < 18.5) return 'Kurus';
  if (imt <= 25) return 'Normal';
  if (imt <= 27) return 'Gemuk';
  return 'Obesitas';
};

// GET all IMT data
const getAll = async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM imt_data ORDER BY updated_at DESC'
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// GET by nomor_hp
const getByPhone = async (req, res) => {
  try {
    const { nomor_hp } = req.params;
    const result = await pool.query(
      'SELECT * FROM imt_data WHERE nomor_hp = $1',
      [nomor_hp]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Data tidak ditemukan' });
    }
    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// CHECK if phone exists
const checkPhone = async (req, res) => {
  try {
    const { nomor_hp } = req.params;
    const result = await pool.query(
      'SELECT id, nomor_hp FROM imt_data WHERE nomor_hp = $1',
      [nomor_hp]
    );
    res.json({ success: true, exists: result.rows.length > 0 });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// CREATE new IMT data
const create = async (req, res) => {
  try {
    const { nomor_hp, nama, tinggi_badan, berat_badan } = req.body;

    if (!nomor_hp || !nama || !tinggi_badan || !berat_badan) {
      return res.status(400).json({ success: false, message: 'Semua field wajib diisi' });
    }

    const imt_score = calculateIMT(parseFloat(berat_badan), parseFloat(tinggi_badan));
    const status = getStatus(imt_score);

    const result = await pool.query(
      `INSERT INTO imt_data (nomor_hp, nama, tinggi_badan, berat_badan, imt_score, status)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [nomor_hp, nama, parseFloat(tinggi_badan), parseFloat(berat_badan), parseFloat(imt_score.toFixed(2)), status]
    );

    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (err) {
    if (err.code === '23505') {
      return res.status(409).json({ success: false, message: 'Nomor HP sudah terdaftar', exists: true });
    }
    res.status(500).json({ success: false, message: err.message });
  }
};

// UPDATE IMT data
const update = async (req, res) => {
  try {
    const { nomor_hp } = req.params;
    const { nama, tinggi_badan, berat_badan } = req.body;

    if (!nama || !tinggi_badan || !berat_badan) {
      return res.status(400).json({ success: false, message: 'Semua field wajib diisi' });
    }

    const imt_score = calculateIMT(parseFloat(berat_badan), parseFloat(tinggi_badan));
    const status = getStatus(imt_score);

    const result = await pool.query(
      `UPDATE imt_data SET nama=$1, tinggi_badan=$2, berat_badan=$3, imt_score=$4, status=$5, updated_at=NOW()
       WHERE nomor_hp=$6 RETURNING *`,
      [nama, parseFloat(tinggi_badan), parseFloat(berat_badan), parseFloat(imt_score.toFixed(2)), status, nomor_hp]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Data tidak ditemukan' });
    }

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// DELETE IMT data
const remove = async (req, res) => {
  try {
    const { nomor_hp } = req.params;
    await pool.query('DELETE FROM imt_data WHERE nomor_hp = $1', [nomor_hp]);
    res.json({ success: true, message: 'Data berhasil dihapus' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = { getAll, getByPhone, checkPhone, create, update, remove };
