const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/imtController');

router.get('/', ctrl.getAll);
router.get('/check/:nomor_hp', ctrl.checkPhone);
router.get('/:nomor_hp', ctrl.getByPhone);
router.post('/', ctrl.create);
router.put('/:nomor_hp', ctrl.update);
router.delete('/:nomor_hp', ctrl.remove);

module.exports = router;
