require('dotenv').config();
const express = require('express');
const cors = require('cors');
const pool = require('./config/database');
const imtRoutes = require('./routes/imtRoutes');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type'],
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', db: 'connected', timestamp: new Date() });
  } catch {
    res.status(500).json({ status: 'error', db: 'disconnected' });
  }
});

app.use('/api/imt', imtRoutes);

// Auto-run migration on startup
const initDB = async () => {
  let retries = 10;
  while (retries > 0) {
    try {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS imt_data (
          id SERIAL PRIMARY KEY,
          nomor_hp VARCHAR(20) UNIQUE NOT NULL,
          nama VARCHAR(100) NOT NULL,
          tinggi_badan DECIMAL(5,2) NOT NULL,
          berat_badan DECIMAL(5,2) NOT NULL,
          imt_score DECIMAL(6,2),
          status VARCHAR(20),
          created_at TIMESTAMP DEFAULT NOW(),
          updated_at TIMESTAMP DEFAULT NOW()
        );
      `);
      console.log('✅ Database initialized');
      break;
    } catch (err) {
      retries--;
      console.log(`⏳ Waiting for DB... (${retries} retries left)`);
      await new Promise(r => setTimeout(r, 3000));
    }
  }
};

initDB().then(() => {
  app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
  });
});
