require('dotenv').config();
const express = require('express');
const cors = require('cors');
const imtRoutes = require('./routes/imtRoutes');
const db = require('./config/database');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type'],
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/health', async (req, res) => {
  try {
    await db.query('SELECT 1');
    res.json({ status: 'OK', db: 'connected', timestamp: new Date() });
  } catch (err) {
    res.status(503).json({ status: 'ERROR', db: 'disconnected', error: err.message });
  }
});

// API Routes
app.use('/api/imt', imtRoutes);

// 404
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Endpoint tidak ditemukan' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: 'Internal server error' });
});

// Wait for DB then start
const startServer = async () => {
  let retries = 10;
  while (retries > 0) {
    try {
      await db.query('SELECT 1');
      console.log('✅ Database connected');
      break;
    } catch (err) {
      retries--;
      console.log(`⏳ Waiting for database... (${retries} retries left)`);
      await new Promise(r => setTimeout(r, 3000));
    }
  }

  if (retries === 0) {
    console.error('❌ Could not connect to database. Exiting.');
    process.exit(1);
  }

  app.listen(PORT, () => {
    console.log(`🚀 IMT Backend running on port ${PORT}`);
  });
};

startServer();
